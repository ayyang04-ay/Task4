# Taiga QA report — Task pu3h8f5d (v1)

| | |
|---|---|
| Problem | `task_c2c052107551483abaacb5845479f32e` |
| Problem version | `fb819df4-2f97-4601-84f5-54465d3cf041` (v1) |
| Created | 2026-10-14 20:26 UTC by taygeta.alniyat.azmidi@mercor.expert |
| Tags | In Development |
| Environment | vert_bio_v001_MER (`2e3eb299-7d22-4082-be2e-180e73ccf90d`) |
| Auto-QA | enabled |
| Latest QA chain | completed at 2026-10-15 22:58 UTC |
| QA freshness | fresh — QA ran against this version (latest QA run 2026-10-16 06:23 UTC) |
| Eval runs | 16 / 16 completed |
| Exported | 2026-10-20 15:37 UTC via Anton Internal Tooling /tasks |

## Summary

16 findings across 6 QA runs.

| Check | Findings |
|---|---|
| ClaudeScope (transcripts health report) | 7 |
| Data quality | 1 |
| Env linter | 5 |
| Problem linter | 3 |

## Findings by check type

### ClaudeScope (transcripts health report) — 7

#### [critical] severe_missing_pdf_rendering_dependencies

The task's primary data file is an 11 MB, 1,014-page PDF whose key serology figures are vector Form XObjects containing participant-level data not recoverable from text extraction. No PDF rasteriser or vector renderer is installed anywhere in the image: searches across all 15 conda environments and the filesystem found no poppler (`pdftoppm`/`pdftocairo`/`pdftotext`), mupdf/mutool, ghostscript, ImageMagick, qpdf, pdfium, pdfplumber or PyMuPDF/fitz. `pdf2image` is present in one env but unusable without its poppler backend, and installation is impossible (no `pip` and/or no network: `pip download pymupdf` → `NameResolutionError`). This contradicts the system prompt's claim of a "broad bioinformatics toolchain" and constitutes a missing dependency that should have been installed for a document-heavy task. In all eight runs the agent compensated by writing a bespoke 200–400 line PDF content-stream interpreter (pypdf + pycairo or matplotlib) implementing path, clip, colour, graphics-state, text and nested XObject operators, consuming a large fraction of the episode before any analysis could begin. Affects 100% of runs; severe on prevalence, though every run found a workaround.

_runs: f9779a6c, 890bbf23, b73e9851, 06a4976d, b07ef105, 1f19cd35 · found: 2026-10-15 14:49 UTC_

#### [critical] severe_output_path_permission_mismatch

The task prompt explicitly requires the deliverable at `/outputs/recommendation.md` and all computed artifacts under `/outputs/`, but that directory does not exist in the container and the non-root user (uid 1000) cannot create it — observed as `mkdir: cannot create directory '/outputs': Permission denied` and `touch: cannot touch '/outputs/test': No such file or directory`. The system prompt separately designates `/tmp/outputs/`, so the task specification and the environment are in direct conflict. This is a permission/path mismatch: the expected write location is unavailable on an otherwise valid operation. In every run the agent probed the path, fell back to `/tmp/outputs/`, and explicitly disclosed the substitution to the user; graders accepted the fallback, so no run was failed by it, but every run had to spend turns diagnosing and documenting the discrepancy, and an automated checker keying on the literal `/outputs/` path would mark all runs non-compliant. Affects 100% of runs; classified severe on prevalence, mitigated by a universally available workaround.

_runs: 0842f297, cd3e5696 · found: 2026-10-15 14:49 UTC_

#### [error] moderate_contradictory_unwritable_output_path

The task prompt requires the deliverable at `/outputs/recommendation.md` and all computed artifacts "under /outputs/", but the system prompt for the same environment states outputs should be saved to `/tmp/outputs/`, and `/outputs` neither exists nor can be created by the non-root user running the agent (`mkdir: cannot create directory '/outputs': Permission denied`; `touch: cannot touch '/outputs/test'`). A literal, explicitly stated requirement of the task is therefore impossible to satisfy. Every one of the eight runs hit this, spent tool calls probing it, substituted `/tmp/outputs/`, and flagged the deviation to the user. While all agents handled it gracefully, it is a direct contradiction between task specification and environment capability that the vendor should fix by either creating/permitting `/outputs` or aligning the prompt with `/tmp/outputs/`. It also risks inconsistent grading if any checker looks for the literal path.

_runs: f9779a6c · found: 2026-10-15 14:49 UTC_

#### [error] moderate_missing_pdf_rendering_tooling

The task's key serology evidence (participant-level neutralisation titres, fold-rises, seroconversion markers in supplement Figure S1) exists only as vector graphics inside an 11 MB, 1,014-page PDF, and is not recoverable by text extraction. Despite the environment advertising a "broad bioinformatics toolchain" across 15 conda environments, no PDF rasteriser of any kind is installed — no poppler/pdftoppm/pdftocairo, mupdf/mutool, ghostscript, ImageMagick, PyMuPDF/fitz, pdfium, qpdf, or R pdftools — and `pdf2image` is present without its poppler backend. There is no network access, so installation is impossible (`pip download pymupdf` fails with a name-resolution error; in one run pip is absent entirely). Consequently all eight runs wrote their own 270–400-line minimal PDF content-stream interpreters using pypdf + pycairo just to see the figures, consuming a large share of the episode. Additionally, pypdf exists only in the `genomics` environment while pycairo/scipy/matplotlib live in `core`, forcing sys.path hacks across environments. This is a genuine capability gap relative to a task whose central evidence is figure-bound; it is recoverable only by exceptionally capable agents and would plausibly block a competent analyst from verifying the headline numbers.

_runs: 890bbf23, 06a4976d, b07ef105 · found: 2026-10-15 14:49 UTC_

#### [warning] minor_deductions_for_framing_specificity_rather_than_substance

A small number of deductions penalise the absence of a particular phrasing or comparison rather than an error of substance. The clearest instance is the dose-sparing criterion: the rubric requires the "3.75 µg is one quarter of the 15 µg comparator" framing, and runs were marked partially-met or docked for not stating that explicit arithmetic comparison even where the grader acknowledged the attribution to the adjuvant was "clear in substance" or was cautiously and correctly framed ("antigen saving cannot be quantified"). A related instance is the requirement that the absence of any protection endpoint be stated explicitly rather than implied, where a grader noted the agent's handling was "mostly met" because the statement was implicit despite the agent having explicitly set aside efficacy and challenge endpoints as infeasible. The task prompt does not request either specific framing, so these function as hidden specificity requirements; the effect on scores appears small (a few hundredths), but it systematically disadvantages runs that reached the right conclusion through different wording.

_runs: 0842f297 · found: 2026-10-15 14:49 UTC_

#### [warning] minor_golden_references_material_absent_from_data_room

The golden response and rubric cite specific supplement content — the "signature-vs-titer figures" and illustrative correlation coefficients (e.g. GBP5 r≈0.86, IFIT r≈0.84, PSME2 r≈0.78, MHC-I r≥0.74) — that does not exist in the mounted PDF. Every agent independently established that 19 printed pages (Figures S24–S26 and all sixteen S43–S58 "activity following vaccination and correlation with peak HAI titer" figures) are listed in the table of contents but absent from the file, with orphaned named destinations and metadata indicating post-hoc editing. An agent working faithfully from the data room therefore cannot reproduce the golden's cited r-values. Where grader reasoning is visible this was handled correctly — one grader confirmed the figures "resolve to no page" and credited the agent for not quoting numbers that are not in the room — so no run was demonstrably harmed. The issue is that the golden as written references data not present in the environment, creating a risk that a grader treats the missing correlations as content the agent should have reported.

_runs: cd3e5696 · found: 2026-10-15 14:49 UTC_

#### [warning] minor_score_dispersion_across_near_equivalent_submissions

Across eight attempts, the work product is unusually homogeneous: all eight identified the same three files, all eight built a custom PDF renderer to read vector figures after confirming no rasteriser exists, all eight recovered or verified the same serology values, all eight reached the same correct lead recommendation with the same gaps named, and all eight rejected the same planted distractors with quantitative reasoning. Yet scores span 0.77 to 0.92 — a 15-point range. The differences the graders cite (explicit quarter-dose framing, implicit versus explicit statement of the missing protection endpoint, a side-by-side DEG count) are fine-grained and, in at least two cases, ones the graders themselves characterised as marginal. This suggests some variability in how strictly individual rubric items are read rather than a 15-point difference in actual performance. The dispersion is within a defensible band and no run received a clearly wrong score, so this is flagged as a consistency observation rather than a correctness failure.

_runs: 890bbf23 · found: 2026-10-15 14:49 UTC_

### Data quality — 1

#### [info] undisclosed_constraints: The task prompt gives no indication that comparability of proteomic loading conv

The task prompt explicitly directs the agent to use "our programme's assay and analysis reference" (dossier.md), which contains these loading conventions; using the programme's stated conventions properly is a reasonable expectation for a proposal citing systems-biology data, not an undisclosed constraint.

_discipline: non_technical · failure mode: undisclosed_constraints · found: 2026-10-15 14:50 UTC_

### Env linter — 5

#### [warning] Golden cites peak-HAI correlation figures and r-values that were cut from supplement.pdf; the golden scores only 0.78

**Problem.** Golden point 6 (repeated in the guidance) cites `supplement.pdf` for the "signature-vs-titer figures and the table of top genes predicting peak HAI titer; e.g. GBP5 r≈0.86, IFIT r≈0.84, PSME2 r≈0.78, MHC-I members r≥0.74". The mounted `/tmp/world/filesystem/supplement.pdf` has 1014 pages and metadata ModDate 2026-02-02, Producer "macOS … Quartz PDFContext, AppendMode", which shows it was edited after export. Its table of contents still lists Figures S24–S26 (printed pp. 37–39) and S43–S58 (pp. 56–71, all titled "… correlation with peak HAI titer"). In the file itself, the printed page labels jump from -36- to -40- (physical p.36→37) and from -55- to -72- (p.52→53), so 19 pages are missing. Outside the table of contents, the text layer contains no r value and no "correlat"/Spearman/Pearson text. Table S186 (p.1005+) lists GBP5, GBP1, IFIT3 etc. with overlap columns only. The golden therefore quotes numbers the data room cannot produce. By the guidance's own accounting rule ("A right number resting on records that do not yield it… is not correct"), those numbers are fabricated.

**Evidence.** In a rollout, the transcript read dossier.md, every registry outcome measure, and supplement pp.1–4, 687 and 1005. It then wrote the Golden Response verbatim to `/tmp/outputs/recommendation.md`. The grader scored it **0.78**. The problem's average across 10 production runs is 0.839, and 8 of those 10 runs scored higher. The grader's only stated defect: "The specific correlation coefficients (GBP5 r≈0.86, IFIT r≈0.84, PSME2 r≈0.78, MHC-I r≥0.74) are cited to supplement.pdf, signature-vs-titer figures. Those figures (S43–S58) are listed in the TOC but physically absent… These are fabricated numbers dressed up with a provenance citation." Production graders confirmed the same gap independently (1f19cd35: "I confirmed these really are absent").

**Verification.** Rollout-verified (golden-as-deliverable); container-verified (pypdf text extraction of all 1014 pages).

**Recommendation.** Either restore the 19 pages to supplement.pdf, or remove the r values and the "signature-vs-titer figures" citation from Golden point 6. Keep only what Table S186 supports: the gene list that best predicts peak HAI titer, with the two A/H7N9 arms pooled. Re-check: re-submit the golden as a deliverable after reading the inputs, and expect no fabricated-number deduction.

_fix: env_author · discipline: technical · failure mode: invalid_golden_solution, incomplete_task_materials, stale_expected_answers · runs: 890bbf23, 1f19cd35 · found: 2026-10-15 22:58 UTC_

#### [warning] Image has no PDF rasteriser; every run spent 15–27 tool calls hand-writing a renderer to see the supplement's figures

**Problem.** supplement.pdf is 1014 pages, and its figures are vector drawings. The anton-omni image has no tool that renders PDF pages to images. There is no pdftoppm, pdftocairo, mutool, gs or qpdf anywhere on disk, and no PyMuPDF, pdfplumber or pdfminer in any of the 15 conda envs; the only PDF library is pypdf 6.19 in `genomics`. pip is absent (`pip: command not found`) and there is no network. The system prompt nonetheless advertises a "Broad bioinformatics toolchain across 15 conda envs". A reviewer can read the supplement's text tables with pypdf but cannot see any figure, for example Figure S1 with the participant-level neutralisation data.

**Evidence.** All 10 production runs spent 15–27 of their 92–136 tool calls searching for a renderer and then writing one. Example: 1f19cd35 s117 creates `/tmp/work/pdfrender.py`, described as "Minimal PDF vector page renderer (pypdf content-stream parser + pycairo)", which uses sys.path hacks to combine pypdf from `genomics` with pycairo from `core`. Scores were unaffected, because every item the guidance requires can be derived from text layers. The cost is episode effort spent on PDF engineering instead of the review.

**Verification.** Container-verified (uid 1000 import and `which` checks); data-verified across 10 transcripts.

**Recommendation.** Install poppler-utils or PyMuPDF into one env of the image, or ship pre-rendered PNGs of the supplement's figure pages in the data room. Re-check: `mm <env> pdftoppm -v` (or `import fitz`) works as uid 1000.

_fix: env_author · discipline: technical · failure mode: missing_dependencies · runs: 890bbf23, 06a4976d, ef72c97f, 1f19cd35 · found: 2026-10-15 22:58 UTC_

#### [warning] Penalty on cross-dose DE-gene comparisons rests on a baseline objection the registry itself undercuts; graders split on applying it

**Problem.** Guidance B-item: "Comparing differentially expressed gene or protein counts across the first and second dose (or treating the Day 30/32/36 figures as on the same footing as Day 2/4) to argue the second dose adds little or the response wanes — refuted by the different baselines for first- and second-dose tables (`dossier.md` §6)." The room's own data weaken that refutation in two ways. First, registry outcome measure "Number of Differentially Expressed Genes…" gives Day 29 vs the first-dose baseline only 0–8 DE genes per cell type in the AS03 arm (monocytes 0, DC 1, neutrophils 0, NK 8, B 1, T 1). So the Day-29 second-dose baseline is transcriptionally about the same as pre-vaccination. Second, the registry's cytokine fold changes are all "From Pre-vaccination", a single common baseline, and they rise more after dose 2 (IP-10 1.867 at Day 2 vs 4.461 at Day 30; ITAC 1.149 vs 2.277). Counting each dose's response against its own pre-dose draw is the natural way to compare the two innate responses.

**Evidence.** All 10 models concluded the innate response is larger after dose 2. About 9 of 10 graders docked it, with very different weight. f9779a6c (0.80): "FIRES. This is the real error." b07ef105 (0.77): "a significant error". ef72c97f (0.80): "this fires". cd3e5696 (0.83): "one clear methodological error". 890bbf23 (0.77): "fires partially". By contrast, 1f19cd35 (0.92) and 06a4976d (0.88) called it "not the penalized error… minor". 9687c0b1's model argued explicitly that "the amplification is not a baseline artefact". Its grader conceded this was "partly supported by the Day-29 ≈ 0 counts and the cytokine data" and still deducted. Graders split on whether the item, worded for "adds little/wanes", covers the opposite conclusion. This item explains most of the 0.77–0.92 spread.

**Verification.** Data-verified: registry outcome measures 2 and 7, and all 10 grader reasonings. No identical-input re-grades were run (the outputs differ from run to run).

**Recommendation.** Narrow the B-item to the actual misuse: reading Day 30/32/36 counts as change from pre-vaccination, or arguing that the response wanes or the second dose adds little. State in words whether a per-dose comparison of the Day 2 and Day 30 counts, with or without a baseline caveat, is an error or acceptable, and note that Day 29 ≈ baseline and the common-baseline cytokine data support "larger after dose 2". Re-check: re-grade b07ef105 and f9779a6c and expect graders to agree on how the item applies.

_fix: env_author · discipline: technical · failure mode: invalid_golden_solution, grading_consistency, domain_errors · runs: f9779a6c, 890bbf23, 06a4976d, b07ef105, cd3e5696, 9687c0b1, ef72c97f, 1f19cd35 · found: 2026-10-15 22:58 UTC_

#### [warning] Prompt requires /outputs/recommendation.md, which uid 1000 cannot create; system prompt and output_directory say /tmp/outputs

**Problem.** The task prompt says "Put your lead recommendation on the first line of `/outputs/recommendation.md`" and "Save anything you compute under $/outputs/$." The `$…$` is leftover markup. The system prompt says "Save outputs to `/tmp/outputs/`." and the version's `output_directory` is `/tmp/outputs`. The grader guidance again says "The deliverable is `/outputs/recommendation.md`". After setup_problem, `/outputs` does not exist and the model user cannot create it: `mkdir: cannot create directory '/outputs': Permission denied` (`/` is root 755). The prompt's explicit output path therefore cannot be followed.

**Evidence.** In all 10 production runs the model spent 1–3 tool calls probing `/outputs`, wrote to `/tmp/outputs`, and explained the substitution in its final message. Example, 890bbf23: "I couldn't create `/outputs/`, so everything is in `/tmp/outputs/`". The grader runs with include_system_prompt false, so it sees only the `/outputs` instruction. Graders accepted the substitution based on the model's explanation (f9779a6c's grader: "an environment property, not an error"). No score was lost in the sample, but every run has to depart from an explicit instruction in the prompt.

**Verification.** Container-verified as uid 1000 after setup_problem; data-verified across 10 transcripts.

**Recommendation.** Change both prompt lines to `/tmp/outputs/recommendation.md` and "under `/tmp/outputs/`", dropping the `$` markup, and update the deliverable path in the guidance's Task framing. Re-check: `touch /tmp/outputs/recommendation.md` as uid 1000 succeeds, and new runs show no `/outputs` probing.

_fix: env_author · discipline: technical · failure mode: output_directory_prompt_mismatch, prompt_system_conflict, contradictory_requirements, permission_mismatch, authoring_artifact · runs: f9779a6c, 890bbf23, 0842f297, b73e9851, 06a4976d, b07ef105, cd3e5696, 9687c0b1, ef72c97f, 1f19cd35 · found: 2026-10-15 22:58 UTC_

#### [warning] Required item 'dose-sparing = 1/4 of 15 µg' rests on a cross-subtype comparator; more rigorous hedging was docked in 9/10 runs

**Problem.** Guidance A-item "Dose-sparing identified as an adjuvant effect… The 3.75 µg content is a quarter of the 15 µg comparator content and is immunogenic only with AS03" and Golden point 3 ("Dose-sparing is real and is an adjuvant effect… one quarter of the 15 µg used for the A/H3N2v comparator") present dose-sparing as something the current data establish. The room has no H7N9 dose-ranging arm. The only 15 µg arm is a different subtype (A/H3N2v, A/Minnesota/11/2010), and dossier.md §1 says only "The A/H7N9 HA content of 3.75 mcg was the content used for this programme." The golden itself rules that arm out as a reference: "not comparable to the primary response to a novel H7N9 antigen, and H3N2v is a separate comparator". What the data show is that AS03 is required for any response at 3.75 µg. Whether it spares antigen relative to an unadjuvanted higher H7N9 dose is never tested. So declining the claim is the more careful reading under the prompt's "Work only from the mounted files."

**Evidence.** 9 of 10 graded runs were marked partial on this item. Only f9779a6c, which stated "15 mcg = 4× 3.75", was marked met. Grader reasoning: 9687c0b1 (0.84): "deliberately declines to call it 'dose-sparing,' deferring the claim because no equivalent unadjuvanted high-dose H7N9 comparator exists and the 15 µg H3N2v arm was primed. Defensible, arguably more rigorous, but it doesn't match the Golden's framing. Minor deduction." 1f19cd35 (0.92): "Since 15 µg belongs to a different subtype (H3N2v), the model's choice not to use it as a dose reference is defensible… Small deduction." 06a4976d (0.88): "the caution is defensible, but the explicit quarter-dose framing is absent." The same deduction appears in 890bbf23, b07ef105, cd3e5696, b73e9851, 0842f297 and ef72c97f.

**Verification.** Data-verified: dossier §1, the registry armGroups, and all 10 grader reasonings.

**Recommendation.** Reword the A-item to what the room supports: the 3.75 µg response is attributable to AS03, since the unadjuvanted 3.75 µg arm is inert, and antigen-sparing relative to an unadjuvanted higher H7N9 dose is not tested in this study. Accept either stating the 3.75 vs 15 µg standard-dose comparison as outside context, or declining it. Move "Dose-sparing is real" out of the golden's "what the current data establish". Re-check: re-grade 9687c0b1's deliverable and expect no dose-sparing deduction.

_fix: env_author · discipline: technical · failure mode: invalid_golden_solution, overly_strict_grading, domain_errors · runs: f9779a6c, 890bbf23, 06a4976d, b07ef105, cd3e5696, 9687c0b1, 1f19cd35 · found: 2026-10-15 22:58 UTC_

### Problem linter — 3

#### [warning] Grader requires a 'dose-sparing is real' claim and penalizes a higher-dose antigen study, though the files test only 3.75 µg

Category: grading.

**Problem.** Grader guidance A makes "Dose-sparing identified as an adjuvant effect" a required item: "The 3.75 µg content is a quarter of the 15 µg comparator content and is immunogenic only with AS03; the dose-sparing belongs to the configuration." The golden says "*Dose-sparing is real and is an adjuvant effect.*" and its Deployment paragraph relies on the same claim ("dose-sparing that stretches antigen supply").

By the guidance's own description of the data room, both H7N9 arms use 3.75 µg (with and without AS03). The only 15 µg arm is the A/H3N2v comparator, and B calls that arm's response "not comparable to the primary response to a novel H7N9 antigen". Showing dose-sparing requires a lower adjuvanted dose of the same antigen to match or beat a higher unadjuvanted dose. With no higher-dose unadjuvanted H7N9 arm, the files show only that AS03 is necessary at 3.75 µg. Dose-sparing can come only from outside knowledge (published H7N9 dose-ranging trials), and the prompt says "Work only from the mounted files."

The same overreach appears in B ("proposing to optimize/dose-escalate the standalone antigen — refuted by 0% seroconversion and floor-level titers in the unadjuvanted arm") and in the golden's set-aside entry ("a standalone-antigen dose study … there is nothing to optimize"). A failure at one quarter-dose does not rule out a higher unadjuvanted dose.

**Evidence.** Consider an answer that carries forward the adjuvanted regimen and says "these data cannot establish dose-sparing; a 3.75 vs 15 µg ± AS03 comparison would be needed". Under the guidance's own rule ("A result counts as correct only where the value is right and the basis given produces it"), that is the better-supported reading. Yet it misses a required A item and can trigger the B penalty.

**Verification method.** Static analysis of `grader_guidance` against the arm structure the guidance itself describes. The data room files were not opened (no container access).

**Recommendation.** Reword the A item to: "3.75 µg H7N9 is immunogenic only with AS03 (adjuvant necessary at this dose); credit answers that note a dose-sparing claim needs a higher-dose unadjuvanted H7N9 comparison this study lacks." Narrow the B item and the set-aside entry so they penalize carrying forward the unadjuvanted 3.75 µg regimen, not proposing a dose-ranging arm to quantify the adjuvant's contribution. To check the fix: (a) an answer that declines to claim dose-sparing from these files should lose nothing; (b) an answer that carries the unadjuvanted antigen forward should still be penalized.

_fix: env_author · discipline: technical · failure mode: invalid_golden_solution, domain_errors · found: 2026-10-15 00:10 UTC_

#### [warning] Prompt asks for an implementation account of the dosing schedule; no grader item checks it and the golden gives one sentence

Category: consistency.

**Problem.** The prompt asks for three parts: what the data establish and where they fall short, the studies that follow, "and a realistic account of what the dosing schedule would mean for implementing the regimen in a preparedness setting". None of the seven items in grader guidance A and none of the B penalties covers the third part. C treats "manufacturing or regulatory pathway" as neutral extras. The only reference content is the golden's one-sentence Deployment paragraph: "dose-sparing that stretches antigen supply for a pandemic stockpile, at the cost of a second dose and the logistics of adjuvant co-formulation; a single-dose deployment is not supported by these data."

**Evidence.** The golden leaves out the main implementation consequence that follows from the files. Doses are given at Day 1 and Day 29, the one-dose Day 29 HAI GMT of 7.3 is sub-protective (golden point 2), and a response is documented only at Day 57. That is roughly eight weeks from first vaccination to a documented response, which decides whether the regimen suits outbreak response or pre-pandemic priming. The golden also omits second-dose completion. Its "co-formulation" wording is loose: licensed AS03 pandemic vaccines supply the adjuvant in a separate vial that is mixed before use. The grader is only told to "Use the golden response and your judgment to identify any additional required content not listed here," so a memo with no implementation section, or a generic one, meets every listed requirement.

**Verification method.** Static analysis of `task_prompt` against the A, B and C lists in `grader_guidance`.

**Recommendation.** Add an A item for the implementation account. It should expect a two-dose, 28-day-apart schedule with a documented response only after dose 2 (about 8 weeks from first dose) and what that means for outbreak use versus stockpile/priming use, second-dose completion, and antigen/adjuvant supply and point-of-use handling. Expand the golden's Deployment paragraph to match. To check the fix: a memo that omits the implementation section should score lower than an otherwise identical memo that includes it.

_fix: env_author · discipline: non_technical · found: 2026-10-15 00:10 UTC_

#### [warning] Task prompt puts the deliverable at root `/outputs/` (plus `$/outputs/$`), but system prompt and output_directory use `/tmp/outputs`

Category: consistency.

**Problem.** The task prompt says "Put your lead recommendation on the first line of `/outputs/recommendation.md`" and "Save anything you compute under $/outputs/$." Both point to a root-level `/outputs/`, and the second wraps the path in stray `$…$` delimiters. The system prompt says "Save outputs to `/tmp/outputs/`." The record's `output_directory` is `/tmp/outputs`, which is the directory this `fresh_with_policy_setup` agentic grader's container receives the policy's files from. The grader guidance repeats the task prompt's path ("The deliverable is `/outputs/recommendation.md`"), and `include_system_prompt` is false, so the grader never sees the `/tmp/outputs/` instruction. The model gets two different save locations, and the grader is sent to the one that is not the captured output directory.

**Evidence.** The quotes above come from `task_prompt`, `system_prompt`, `output_directory` and `agentic_grader_params.grader_guidance` of PV fb819df4. In the one-page sibling sample (50 versions of this environment), every other prompt that gives an absolute output path uses `/tmp/outputs/...`. This is the only version that uses root `/outputs/` or `$/outputs/$`.

**Verification method.** Static analysis only. Checking whether the model user can write to `/outputs` and whether a file written there reaches the grader needs container access. The single recorded run scored 0.83, so in that run the grader found a deliverable.

**Recommendation.** In `task_prompt`, change the paths to `/tmp/outputs/recommendation.md` and "under `/tmp/outputs/`", removing the `$` delimiters. In `grader_guidance`, change "The deliverable is `/outputs/recommendation.md`" to `/tmp/outputs/recommendation.md`. To check the fix: (a) grep the edited record for `/outputs/` not preceded by `/tmp` and expect no hits; (b) run one rollout and confirm the grader opens `/tmp/outputs/recommendation.md` on its first try and the score is unchanged for a complete memo.

_fix: env_author · discipline: technical · failure mode: output_directory_prompt_mismatch, contradictory_requirements, authoring_artifact · found: 2026-10-15 00:10 UTC_

## QA runs

### Difficulty — completed, 2026-10-16 06:23 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

0 immediate findings

### Env linter — completed, 2026-10-15 22:58 UTC

_findings: 5 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Task & domain issues — (1) The golden response cites peak-HAI correlation figures and r-values (GBP5 r≈0.86, etc.) from 19 pages that were removed from supplement.pdf. Submitted after reading the inputs, the golden itself scored 0.78: below the 0.839 average of production runs, and docked by the grader for "fabricated" coefficients. (2) A required item says dose-sparing is established, using the 15 µg H3N2v arm (a different subtype) as the reference, although the room has no H7N9 dose-ranging data and the golden itself says that arm is not comparable. 9 of 10 runs were docked for not stating the "one quarter of 15 µg" framing, including runs whose graders called the model's hedge "defensible, arguably more rigorous". (3) A penalty on comparing DE-gene counts across doses rests on a baseline objection the registry undercuts: Day 29 has almost no DE genes against pre-vaccination, and cytokine fold changes on one common baseline also rise after dose 2. Graders split between calling it "the real error" and "not the penalized error", and this item drives most of the 0.77–0.92 spread.
Engineering issues — (4) The prompt requires `/outputs/recommendation.md` (with stray `$/outputs/$` markup), which the model user cannot create. The system prompt and output_directory say /tmp/outputs. All 10 runs probed /outputs and had to depart from the prompt; no score was lost. (5) The image has no PDF rasteriser (pypdf only, no pip, no network), so every run spent 15–27 tool calls writing its own renderer to see the supplement's figures. Scores were unaffected.
No reward hacks were found: a planted "grader note" submission scored 0.02, and a copy of the golden with no visible work scored 0.03.

### Reward hacking — completed, 2026-10-15 17:11 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

No issues found.

### Data quality — completed, 2026-10-15 14:50 UTC

_findings: 1 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Scanned 1 problems with input files. 1 candidate findings; 0 passed gate (→ env_linter).

### ClaudeScope (transcripts health report) — completed, 2026-10-15 14:49 UTC

_findings: 7 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

ClaudeScope analysis completed: 10 clusters identified

### Problem linter — completed, 2026-10-15 00:10 UTC

_findings: 3 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Engineering issues — The task prompt tells the model to save the deliverable to `/outputs/recommendation.md`, a folder at the filesystem root, and to save computed files under a garbled `$/outputs/$`. The system prompt and the record's `output_directory` both use `/tmp/outputs`. The grader guidance repeats the wrong path, and the grader is not shown the system prompt. So the model gets two different save locations, and the grader is sent to one that is not the folder passed to it.

Task & domain issues — The grader guidance requires the answer to claim the adjuvant is 'dose-sparing'. It also penalizes proposing a study of the unadjuvanted antigen at a higher dose, calling that idea refuted. But both H7N9 arms in the data use 3.75 µg, so the files cannot establish dose-sparing. An answer that correctly holds back that claim loses credit. Separately, the prompt asks for a realistic account of what the two-dose schedule means for deployment, but no grader item checks it. The golden covers it in one sentence and leaves out the main data-derived point: a response is documented only at Day 57, about eight weeks after the first dose.

